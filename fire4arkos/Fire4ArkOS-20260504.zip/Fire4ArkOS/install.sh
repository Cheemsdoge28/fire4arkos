#!/bin/bash
# ============================================================================
# Fire4ArkOS Installer — Self-Contained
# ============================================================================
# Usage:
#   1. Copy dist/release/Fire4ArkOS to /roms/ports/Fire4ArkOS or /roms/tools/Fire4ArkOS
#   2a. (Option A) SSH and run installer:
#       cd /roms/ports/Fire4ArkOS && sudo bash install.sh
#   2b. (Option B) Create ES "Installer" entry, select it to run:
#       (uses install-from-es.sh for privilege escalation)
#   3. Restart EmulationStation (Start > Quit > Restart EmulationStation)
#   4. "Fire4ArkOS Browser" appears as a system in the main menu
#
# Options:
#   --uninstall    Remove Fire4ArkOS from the system
#   --rebuild      Force native compile even if pre-built binary exists
#   --from-es      Run non-interactively from EmulationStation wrapper
# ============================================================================

set -e

# ---------- Constants ----------
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_NAME="Fire4ArkOS"
INSTALL_DIR="$SCRIPT_DIR"          # Self-contained: use actual directory
ES_CFG="/etc/emulationstation/es_systems.cfg"
ES_CFG_DUAL="/etc/emulationstation/es_systems.cfg.dual"
LAUNCHER_SCRIPT="$INSTALL_DIR/Fire4ArkOS Browser.sh"
SYSTEM_NAME="fire4arkos"
PLATFORM_TAG="${PLATFORM_TAG:-$SYSTEM_NAME}"
THEME_NAME="${THEME_NAME:-$SYSTEM_NAME}"

# ============================================================================
# Logging helpers
# ============================================================================
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

log_step() { echo -e "\n${CYAN}${BOLD}[$1]${NC} $2"; }
log_ok()   { echo -e "  ${GREEN}✓${NC} $1"; }
log_warn() { echo -e "  ${YELLOW}⚠${NC} $1"; }
log_err()  { echo -e "  ${RED}✗${NC} $1"; }
log_info() { echo -e "  $1"; }

FORCE_REBUILD=0
for arg in "$@"; do
    case "$arg" in
        --rebuild) FORCE_REBUILD=1 ;;
        --reinstall-deps) REINSTALL_DEPS=1 ;;
    esac
done

# If launched from EmulationStation installer wrapper, avoid launching GUI
# apps accidentally by unsetting DISPLAY and XAUTHORITY early. The
# `install-from-es.sh` wrapper sets `FIRE4ARKOS_FROM_ES=1` in the env.
if [ "${FIRE4ARKOS_FROM_ES:-0}" = "1" ]; then
    unset DISPLAY XAUTHORITY
    export DISPLAY=""
    export XAUTHORITY=""
fi

# ---------- Uninstall ----------
if [ "$1" = "--uninstall" ]; then
    echo -e "${BOLD}${APP_NAME} Uninstaller${NC}"
    echo ""

    # Remove launcher script
    rm -f "$LAUNCHER_SCRIPT"
    rm -f "/usr/local/bin/fire4arkos"
    rm -f "/usr/local/bin/firefox-framebuffer-wrapper.py"
    log_ok "Removed launch script, shell command, and wrapper symlink"

    # Remove ES system entries
    for cfg in "$ES_CFG" "$ES_CFG_DUAL"; do
        if [ -f "$cfg" ] && grep -q "fire4arkos" "$cfg"; then
            sed -i "/<!-- Fire4ArkOS Browser/,/<\/system>/d" "$cfg"
            log_ok "Removed $SYSTEM_NAME entry from $cfg"
        fi
    done

    echo ""
    echo -e "${GREEN}Uninstall complete.${NC} Restart EmulationStation to apply."
    echo "Your files in $INSTALL_DIR are preserved."
    exit 0
fi

# ---------- Banner ----------
echo ""
echo -e "${BOLD}============================================${NC}"
echo -e "${BOLD}  ${APP_NAME} Installer${NC}"
echo -e "${BOLD}============================================${NC}"
echo ""

# ---------- Pre-flight checks ----------
if [ "$(id -u)" -ne 0 ]; then
    log_err "This script must be run as root (use: sudo bash install.sh)"
    exit 1
fi

for required in firefox-framebuffer-wrapper.py run_browser.sh; do
    if [ ! -f "$SCRIPT_DIR/$required" ]; then
        log_err "$required not found in $SCRIPT_DIR"
        log_err "Make sure you're running this from the Fire4ArkOS directory."
        exit 1
    fi
done

ARCH="$(uname -m)"

# ============================================================================
# Step 1: Install runtime dependencies
# ============================================================================
log_step "1/6" "Installing dependencies..."

# ArkOS uses Ubuntu 19.10 (eoan) which is EOL — repos moved to old-releases
fix_apt_sources() {
    local sources="/etc/apt/sources.list"
    if grep -q "archive.ubuntu.com\|security.ubuntu.com\|ports.ubuntu.com" "$sources" 2>/dev/null; then
        if ! grep -q "old-releases.ubuntu.com" "$sources" 2>/dev/null; then
            log_info "Fixing APT sources for EOL Ubuntu (eoan → old-releases)..."
            cp "$sources" "$sources.bak.fire4arkos"
            sed -i 's|http://archive.ubuntu.com|http://old-releases.ubuntu.com|g' "$sources"
            sed -i 's|http://security.ubuntu.com|http://old-releases.ubuntu.com|g' "$sources"
            sed -i 's|http://ports.ubuntu.com|http://old-releases.ubuntu.com|g' "$sources"
            log_ok "APT sources fixed (backup: $sources.bak.fire4arkos)"
        fi
    fi
}

fix_apt_sources

# Fix any broken dpkg state
dpkg --configure -a 2>/dev/null || true
apt-get -y --fix-broken install 2>/dev/null || true

log_info "Updating package lists..."
apt-get update -qq 2>/dev/null || log_warn "apt-get update had errors (some repos may be unreachable)"

# Runtime dependencies only — no build tools unless we need to compile
RUNTIME_DEPS="python3 xvfb xdotool x11-utils apulse alsa-utils pulseaudio-utils libasound2 fonts-liberation ffmpeg fbset fbcat i2c-tools usbutils mmc-utils gdb git"

log_info "Installing runtime dependencies..."
APT_FLAGS="-y"
if [ "$REINSTALL_DEPS" = "1" ]; then
    APT_FLAGS="-y --reinstall"
    log_info "Reinstall mode active: refreshing all dependencies..."
fi
apt-get install $APT_FLAGS $RUNTIME_DEPS 2>&1 | tail -3 || log_warn "Some packages may have failed"

# Firefox
if ! command -v firefox &>/dev/null; then
    log_info "Firefox not found — installing..."
    apt-get install -y firefox-esr 2>/dev/null || \
    apt-get install -y firefox 2>/dev/null || \
    log_warn "Could not install Firefox. Install manually: sudo apt-get install firefox-esr"
fi

# Verify critical runtime deps
MISSING=""
for cmd in python3 Xvfb xdotool firefox; do
    if ! command -v "$cmd" &>/dev/null; then
        MISSING="$MISSING $cmd"
    fi
done
if [ -n "$MISSING" ]; then
    log_err "Missing critical dependencies:$MISSING"
    log_err "Install them manually and re-run this script."
    exit 1
fi

log_ok "All runtime dependencies installed"

if [ ! -f "$SCRIPT_DIR/install-es-system.py" ]; then
    log_err "install-es-system.py not found in $SCRIPT_DIR"
    exit 1
fi

# ============================================================================
# Step 2: Get browser binary (pre-built or compile)
# ============================================================================
log_step "2/6" "Setting up browser binary..."

BROWSER_BIN=""

# Try pre-built binary first (shipped in bin/ or build/)
if [ "$FORCE_REBUILD" -eq 0 ]; then
    for candidate in \
        "$SCRIPT_DIR/bin/browser.arm64" \
        "$SCRIPT_DIR/bin/browser" \
        "$SCRIPT_DIR/build/browser" \
        "$SCRIPT_DIR/browser"; do
        if [ -f "$candidate" ]; then
            BROWSER_BIN="$candidate"
            break
        fi
    done
fi

if [ -n "$BROWSER_BIN" ] && [ "$FORCE_REBUILD" -eq 0 ]; then
    # Verify the binary looks compatible with this architecture using `file` only.
    chmod +x "$BROWSER_BIN"
    if file "$BROWSER_BIN" 2>/dev/null | grep -q "$ARCH"; then
        log_ok "Using pre-built binary: $BROWSER_BIN ($(du -h "$BROWSER_BIN" | cut -f1))"
    else
        # If launched from EmulationStation non-interactively, don't execute
        # the binary or prompt; prefer to continue and let the user rebuild
        # if something fails at runtime.
        if [ "${FIRE4ARKOS_FROM_ES:-0}" = "1" ]; then
            log_warn "Pre-built binary may not match $ARCH — continuing in ES mode"
        else
            log_warn "Pre-built binary exists but may not be compatible with $ARCH"
            echo -n "  Try using it anyway? (y/n, default=y): "
            read -r choice </dev/tty 2>/dev/null || choice="y"
            if [[ ! "$choice" =~ ^[Nn] ]]; then
                log_ok "Using pre-built binary: $BROWSER_BIN"
            else
                BROWSER_BIN=""
            fi
        fi
    fi
fi

# Fall back to native compile if no binary or --rebuild
if [ -z "$BROWSER_BIN" ]; then
    log_info "No pre-built binary available — compiling natively..."

    # Install build dependencies
    BUILD_DEPS="build-essential g++ make pkg-config libsdl2-dev libstdc++-dev libgles2-mesa-dev libegl1-mesa-dev libgl1-mesa-dev libglu1-mesa-dev libglew-dev cmake ninja-build libc6-dev linux-libc-dev"
    log_info "Installing build dependencies..."
    APT_FLAGS="-y"
    if [ "$REINSTALL_DEPS" = "1" ]; then
        APT_FLAGS="-y --reinstall"
    fi
    apt-get install $APT_FLAGS $BUILD_DEPS 2>&1 | tail -3 || {
        log_err "Failed to install build dependencies"
        exit 1
    }

    if [ ! -f "$SCRIPT_DIR/Makefile" ] || [ ! -f "$SCRIPT_DIR/src/main.cpp" ]; then
        log_err "Source code not found (Makefile or src/main.cpp missing)"
        log_err "To compile, you need the full source tree."
        exit 1
    fi

    cd "$SCRIPT_DIR"
    make clean 2>/dev/null || true
    if make native 2>&1 | tail -10; then
        log_ok "Native build successful"
    else
        log_err "Build failed. Check compiler errors above."
        exit 1
    fi

    for candidate in "$SCRIPT_DIR/build/browser" "$SCRIPT_DIR/build/browser.arm64"; do
        if [ -f "$candidate" ]; then
            BROWSER_BIN="$candidate"
            break
        fi
    done

    if [ -z "$BROWSER_BIN" ]; then
        log_err "Browser binary not found after build."
        exit 1
    fi
fi

# Strip debug symbols for smaller binary
strip "$BROWSER_BIN" 2>/dev/null || true
log_ok "Binary ready: $BROWSER_BIN ($(du -h "$BROWSER_BIN" | cut -f1))"

# ============================================================================
# Step 3: Ensure files are executable (self-contained in $INSTALL_DIR)
# ============================================================================
log_step "3/6" "Preparing files..."

# Make all scripts executable in place
chmod +x "$INSTALL_DIR/run_browser.sh" 2>/dev/null || true
chmod +x "$INSTALL_DIR/firefox-framebuffer-wrapper.py" 2>/dev/null || true
chmod +x "$INSTALL_DIR/bin/browser.arm64" 2>/dev/null || true
chmod +x "$INSTALL_DIR"/*.sh 2>/dev/null || true
chmod +x "$INSTALL_DIR"/*.py 2>/dev/null || true

log_ok "Files prepared in: $INSTALL_DIR"

# ============================================================================
# Step 4: Create EmulationStation launch script
# ============================================================================
log_step "4/6" "Creating EmulationStation launch script..."

cat > "$LAUNCHER_SCRIPT" << 'LAUNCH_EOF'
#!/bin/bash
# Fire4ArkOS Browser — EmulationStation Launch Script
# This file is called by EmulationStation when the user selects Fire4ArkOS.

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Set performance governor for the browsing session
for gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo performance > "$gov" 2>/dev/null || true
done

# Launch the browser using local run_browser.sh
export FIRE4ARKOS_INTERNAL_SCALE="${FIRE4ARKOS_INTERNAL_SCALE:-1}"
export FIRE4ARKOS_FRAME_SKIP="${FIRE4ARKOS_FRAME_SKIP:-1}"
export FIRE4ARKOS_SET_GOVERNOR=0
export FIRE4ARKOS_WRAPPER="$SCRIPT_DIR/firefox-framebuffer-wrapper.py"

# When launched from EmulationStation, mark ES-mode so installer/run scripts
# avoid launching display-sensitive helpers and so we can log debug output.
export FIRE4ARKOS_FROM_ES=1

# Log output to a temporary file for debugging when launched from ES.
LOGFILE="/tmp/fire4arkos_es.$$".log
echo "[Fire4ArkOS] Launching (ES mode) PID=$$ LOG=$LOGFILE" > "$LOGFILE"

# Use exec to replace the shell with the run script — EmulationStation will
# then track the correct process. Redirect stdout/stderr to the log file.
exec bash -c '"'$SCRIPT_DIR'/run_browser.sh" "${1:-https://www.google.com}"' >> "$LOGFILE" 2>&1

# Restore ondemand governor after browser exits (this block will run only if
# the exec above is replaced by a wrapper that returns; kept for completeness)
for gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo ondemand > "$gov" 2>/dev/null || true
done
LAUNCH_EOF

chmod +x "$LAUNCHER_SCRIPT"
log_ok "Created: $LAUNCHER_SCRIPT"

# Create system-wide symlink for shell access (matches old release behavior)
if [ -d "/usr/local/bin" ]; then
    ln -sf "$INSTALL_DIR/run_browser.sh" "/usr/local/bin/fire4arkos"
    ln -sf "$INSTALL_DIR/firefox-framebuffer-wrapper.py" "/usr/local/bin/firefox-framebuffer-wrapper.py"
    log_ok "Created shell command: fire4arkos and wrapper symlink"
fi

# ============================================================================
# Step 5: Install theme
# ============================================================================
log_step "5/6" "Installing theme..."

# Try to find the theme directory path
THEME_DIR=""
for candidate in \
    "/etc/emulationstation/themes/es-theme-nes-box" \
    "/etc/emulationstation/themes/es-theme-carbon" \
    "/etc/emulationstation/themes"; do
    if [ -d "$candidate" ]; then
        THEME_DIR="$candidate"
        break
    fi
done

if [ -n "$THEME_DIR" ] && [ -d "$SCRIPT_DIR/theme" ]; then
    # Copy Fire4ArkOS theme to the ES theme directory
    mkdir -p "$THEME_DIR/fire4arkos"
    cp -r "$SCRIPT_DIR/theme"/* "$THEME_DIR/fire4arkos/" 2>/dev/null || true
    chmod -R 755 "$THEME_DIR/fire4arkos"
    log_ok "Theme installed to: $THEME_DIR/fire4arkos"
else
    if [ -d "$SCRIPT_DIR/theme" ]; then
        log_warn "Could not find EmulationStation theme directory (expected in /etc/emulationstation/themes/)"
    fi
fi

# ============================================================================
# Step 6: Register with EmulationStation
# ============================================================================
log_step "6/7" "Registering with EmulationStation..."
python3 "$SCRIPT_DIR/install-es-system.py" --cfg-file "$ES_CFG" --install-dir "$INSTALL_DIR" --platform-tag "$PLATFORM_TAG" --theme-name "$THEME_NAME"
python3 "$SCRIPT_DIR/install-es-system.py" --cfg-file "$ES_CFG_DUAL" --install-dir "$INSTALL_DIR" --platform-tag "$PLATFORM_TAG" --theme-name "$THEME_NAME"

# ============================================================================
# Step 7: Verification
# ============================================================================
log_step "7/7" "Verifying installation..."

ERRORS=0

for check in \
    "launch script:$LAUNCHER_SCRIPT" \
    "run_browser.sh:$INSTALL_DIR/run_browser.sh" \
    "firefox-framebuffer-wrapper.py:$INSTALL_DIR/firefox-framebuffer-wrapper.py"; do
    label="${check%%:*}"
    path="${check#*:}"
    if [ -f "$path" ]; then
        log_ok "$label: $path"
    else
        log_err "$label not found at $path"
        ERRORS=$((ERRORS + 1))
    fi
done

# Check if binary exists (pre-built or will be compiled)
if [ -f "$BROWSER_BIN" ]; then
    log_ok "Browser binary: $BROWSER_BIN ($(du -h "$BROWSER_BIN" | cut -f1))"
else
    log_warn "Browser binary: compiled above (or not available)"
fi

if command -v firefox &>/dev/null; then
    log_ok "Firefox: $(firefox --version 2>/dev/null || echo 'installed')"
else
    log_err "Firefox not found in PATH"
    ERRORS=$((ERRORS + 1))
fi

if command -v apulse &>/dev/null; then
    log_ok "apulse: $(which apulse)"
else
    log_warn "apulse not found — audio may not work"
fi

if [ -f "$ES_CFG" ] && grep -q "<name>$SYSTEM_NAME</name>" "$ES_CFG"; then
    log_ok "EmulationStation: registered"
else
    log_warn "EmulationStation: not registered (file may not exist yet)"
fi

# ---------- Summary ----------
echo ""
echo -e "${BOLD}============================================${NC}"
if [ $ERRORS -eq 0 ]; then
    echo -e "${GREEN}${BOLD}  Installation Complete!${NC}"
else
    echo -e "${YELLOW}${BOLD}  Installation Complete (with $ERRORS warnings)${NC}"
fi
echo -e "${BOLD}============================================${NC}"
echo ""
echo -e "  ${BOLD}Installation directory:${NC} $INSTALL_DIR"
echo ""
echo -e "  ${BOLD}Next steps:${NC}"
echo -e "  1. Restart EmulationStation:"
echo -e "     ${CYAN}Start → Quit → Restart EmulationStation${NC}"
echo -e "  2. Navigate to ${BOLD}Fire4ArkOS Browser${NC} in the system list"
echo -e "  3. Select ${BOLD}Fire4ArkOS Browser.sh${NC} to launch"
echo ""
echo -e "  ${BOLD}Or launch directly:${NC}"
echo -e "     ${CYAN}bash \"$LAUNCHER_SCRIPT\" \"https://www.google.com\"${NC}"
echo ""
echo -e "  ${BOLD}Uninstall:${NC}  sudo bash $INSTALL_DIR/install.sh --uninstall"
echo -e "  ${BOLD}Rebuild:${NC}    sudo bash $INSTALL_DIR/install.sh --rebuild"
echo -e "  ${BOLD}Reinstall:${NC}  sudo bash $INSTALL_DIR/install.sh --reinstall-deps"
echo ""
